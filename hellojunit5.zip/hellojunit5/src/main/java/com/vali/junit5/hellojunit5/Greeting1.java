package com.vali.junit5.hellojunit5;

public interface Greeting1 {
	public String greet(String name);

}
