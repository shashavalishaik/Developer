package com.javaguides.sms.service.impl;

import com.javaguides.sms.service.StudentService;
import java.util.List;

import org.springframework.stereotype.Service;

import com.javaguides.sms.entity.Student;
import com.javaguides.sms.repository.StudentRepository;
import com.javaguides.sms.service.StudentService;

@Service
public class StudentServiceImpl implements StudentService {

	private StudentRepository studentRepository;
	
	
	
	public StudentServiceImpl(StudentRepository studentRepository) {
		super();
		this.studentRepository = studentRepository;
	}



	@Override
	public List<Student> getAllStudents(){
		
		return studentRepository.findAll();
		
	}
	
	@Override
	public Student saveStudent(Student student)
	{
		return studentRepository.save(student);
	}
}
