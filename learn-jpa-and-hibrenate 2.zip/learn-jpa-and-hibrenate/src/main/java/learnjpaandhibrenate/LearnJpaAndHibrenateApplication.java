package learnjpaandhibrenate;

import org.springframework.boot.SpringApplication;

import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LearnJpaAndHibrenateApplication {

	public static void main(String[] args) {
		SpringApplication.run(LearnJpaAndHibrenateApplication.class, args);
	}

}
