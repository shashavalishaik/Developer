package learnjpaandhibrenate.course.springdatajpa;

import org.springframework.data.jpa.repository.JpaRepository;

import learnjpaandhibrenate.course.Course;

public interface CourseSpringDataJpaRepository  extends JpaRepository<Course,Long>{

}

