package learnjpaandhibrenate.course;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import learnjpaandhibrenate.course.jpa.CourseJpaRepository;
import learnjpaandhibrenate.course.springdatajpa.CourseSpringDataJpaRepository;

@Component
public class CourseCommandLineRunner implements CommandLineRunner{
	
	//@Autowired
//	private CourseJpaRepository repository;
	
	@Autowired
	private CourseSpringDataJpaRepository repository;

/*	@Override
	public void run(String... args) throws Exception {

		

		repository.insert(new Course(4, "vali", "shashavali"));
		repository.insert(new Course(5, "kjcnkjnc", "asxj"));
		
		
		repository.deleteById(4);
		
		System.out.println(repository.findById(5));
	
	}*/
	
	
	@Override
	public void run(String... args) throws Exception {

		

		repository.save(new Course(4, "vali", "shashavali"));
		repository.save(new Course(5, "kjcnkjnc", "asxj"));
		repository.save(new Course(6, "kjcjnc", "aj"));
		
		
		repository.deleteById(4l);
		
		System.out.println(repository.findById(5l));
		
		System.out.println(repository.findAll());
	
	}

}
